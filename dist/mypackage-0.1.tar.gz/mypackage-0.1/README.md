# mypackage

This library was created as an example of how to publish your own python package

## building this package locally

"python setup.py sdist"

## Installing this package from Github

"pip install git"

## updating this package from Github

"pip install --upgrade git"


